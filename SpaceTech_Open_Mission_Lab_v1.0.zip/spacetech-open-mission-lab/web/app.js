const state = { lang: localStorage.getItem('st-lang') || 'en', track: localStorage.getItem('st-track') || null };
const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const t = () => MISSION_DATA[state.lang];

function applyLanguage(){
  document.documentElement.lang = state.lang;
  document.documentElement.dir = state.lang === 'ar' ? 'rtl' : 'ltr';
  $('#langBtn').textContent = state.lang === 'en' ? 'العربية' : 'English';
  $$('[data-i18n]').forEach(el => { const key=el.dataset.i18n; if(t().ui[key]) el.textContent=t().ui[key]; });
  renderTracks();
  if(state.track) renderForm();
  const report = localStorage.getItem('st-report');
  if(report) generateReport(false);
}

function renderTracks(){
  const grid=$('#trackGrid'); grid.innerHTML='';
  Object.entries(t().tracks).forEach(([key,tr])=>{
    const btn=document.createElement('button');
    btn.type='button'; btn.className='track-card'+(state.track===key?' active':'');
    btn.innerHTML=`<span class="icon">${tr.icon}</span><h3>${tr.title}</h3><p>${tr.desc}</p>`;
    btn.addEventListener('click',()=>selectTrack(key)); grid.appendChild(btn);
  });
}

function selectTrack(key){
  state.track=key; localStorage.setItem('st-track',key); renderTracks(); renderForm();
  $('#builderSection').classList.remove('hidden');
  $('#builderSection').scrollIntoView({behavior:'smooth',block:'start'});
}

function allFields(){ return [...t().common, ...t().fields[state.track]]; }

function renderForm(){
  if(!state.track) return;
  const form=$('#missionForm'); form.innerHTML='';
  const saved=JSON.parse(localStorage.getItem(`st-form-${state.track}`)||'{}');
  allFields().forEach(f=>{
    const wrap=document.createElement('div'); wrap.className='field'+(f.full?' full':'');
    const label=document.createElement('label'); label.htmlFor=f.id; label.textContent=f.label;
    const hint=document.createElement('span'); hint.className='hint'; hint.textContent=f.hint;
    const input=document.createElement(f.type==='textarea'?'textarea':'input');
    input.id=f.id; input.name=f.id; if(f.type!=='textarea') input.type=f.type;
    input.value=saved[f.id]||''; input.addEventListener('input',saveForm);
    wrap.append(label,hint,input); form.appendChild(wrap);
  });
  $('#builderTitle').textContent=`${t().ui.buildMission} — ${t().tracks[state.track].title}`;
}

function saveForm(){
  const data={}; allFields().forEach(f=>data[f.id]=$(`#${f.id}`)?.value.trim()||'');
  localStorage.setItem(`st-form-${state.track}`,JSON.stringify(data));
  $('#saveStatus').textContent=t().ui.autosaved;
}

function getFormData(){ const data={}; allFields().forEach(f=>data[f.id]=$(`#${f.id}`)?.value.trim()||''); return data; }
function esc(v){ return (v||'—').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m])).replace(/\n/g,'<br>'); }

function generateReport(scroll=true){
  if(!state.track) return;
  saveForm(); const d=getFormData();
  const track=t().tracks[state.track];
  const specific=t().fields[state.track].map(f=>f.id);
  const commonOrder=['problem','objective','users','success'];
  const endOrder=['operations','risks','limits','impact'];
  const section=(id)=>`<h2>${t().reportLabels[id]||id}</h2><p>${esc(d[id])}</p>`;
  let html=`<h1>${esc(d.projectTitle||track.title)}</h1><div class="meta"><span>${track.icon} ${track.title}</span><span>${esc(d.team||'Student team')}</span><span>SpaceTech Open Mission Lab</span></div>`;
  [...commonOrder,...specific,...endOrder].forEach(id=>html+=section(id));
  html+=`<h2>${state.lang==='ar'?'الخطوة التالية':'Next step'}</h2><p>${state.lang==='ar'?'راجع الافتراضات، أضف رسمًا للنظام أو دليل اختبار، ثم قدّم المهمة إلى لجنة مراجعة.':'Review assumptions, add a system diagram or test evidence, and present the mission to a review panel.'}</p>`;
  $('#reportPreview').innerHTML=html; $('#reportSection').classList.remove('hidden');
  localStorage.setItem('st-report','1'); if(scroll) $('#reportSection').scrollIntoView({behavior:'smooth'});
}

function markdownReport(){
  const d=getFormData(), track=t().tracks[state.track], specific=t().fields[state.track].map(f=>f.id), ids=['problem','objective','users','success',...specific,'operations','risks','limits','impact'];
  let md=`# ${d.projectTitle||track.title}\n\n**Track:** ${track.title}  \n**Team:** ${d.team||'—'}  \n**Created with:** SpaceTech Open Mission Lab\n\n`;
  ids.forEach(id=>md+=`## ${t().reportLabels[id]||id}\n\n${d[id]||'—'}\n\n`);
  md+=`## ${state.lang==='ar'?'الخطوة التالية':'Next step'}\n\n${state.lang==='ar'?'راجع الافتراضات، وأضف رسمًا للنظام أو دليل اختبار، ثم قدّم المهمة إلى لجنة مراجعة.':'Review assumptions, add a system diagram or test evidence, and present the mission to a review panel.'}\n`;
  return md;
}

function downloadMarkdown(){
  const blob=new Blob([markdownReport()],{type:'text/markdown;charset=utf-8'}); const a=document.createElement('a');
  a.href=URL.createObjectURL(blob); a.download=(getFormData().projectTitle||'spacetech-mission').replace(/[^\w\-]+/g,'-')+'.md'; a.click(); URL.revokeObjectURL(a.href);
}

function surprise(){
  const track=state.track || Object.keys(t().tracks)[Math.floor(Math.random()*3)];
  const ideas=t().ideas[track]; const idea=ideas[Math.floor(Math.random()*ideas.length)];
  $('#ideaBox').classList.remove('hidden'); $('#ideaBox').innerHTML=`<strong>${t().tracks[track].icon} ${t().tracks[track].title}</strong><br>${idea}`;
}

$('#langBtn').addEventListener('click',()=>{state.lang=state.lang==='en'?'ar':'en'; localStorage.setItem('st-lang',state.lang); applyLanguage();});
$('#ideaBtn').addEventListener('click',surprise);
$('#generateBtn').addEventListener('click',()=>generateReport(true));
$('#downloadBtn').addEventListener('click',downloadMarkdown);
$('#printBtn').addEventListener('click',()=>window.print());
$('#clearBtn').addEventListener('click',()=>{if(!state.track)return; localStorage.removeItem(`st-form-${state.track}`); localStorage.removeItem('st-report'); renderForm(); $('#reportSection').classList.add('hidden');});

applyLanguage();
if(state.track){ $('#builderSection').classList.remove('hidden'); }
