window.MISSION_DATA = {
  en: {
    ui: {
      openSource: "OPEN-SOURCE • ARABIC + ENGLISH",
      heroTitle: "Design a real engineering mission.",
      heroCopy: "Choose a track, define a problem, make engineering decisions, and export a complete student mission report.",
      chooseTrack: "Choose your track", surprise: "Give me an idea", buildMission: "Build the mission", autosaved: "Autosaved locally", generate: "Generate mission report", clear: "Clear", report: "Mission report", download: "Download Markdown", print: "Print", footer: "Open knowledge. Real engineering. Opportunities for everyone."
    },
    tracks: {
      cubesat: { icon:"🛰️", title:"CubeSat Mission Design", desc:"Design a satellite mission, payload, orbit concept, subsystems, and operations." },
      drones: { icon:"🚁", title:"Drone Mission Engineering", desc:"Plan a useful UAV mission with a payload, route, safety plan, and workflow." },
      robotics: { icon:"🤖", title:"Robotics & Smart Systems", desc:"Design a robot using sensors, actuators, control logic, testing, and impact." }
    },
    common: [
      {id:"projectTitle",label:"Project title",hint:"Give the mission a memorable name.",type:"text"},
      {id:"team",label:"Student or team name",hint:"Individual name or team name.",type:"text"},
      {id:"problem",label:"Real-world problem",hint:"Who is affected, where, and why does it matter?",type:"textarea",full:true},
      {id:"objective",label:"Mission objective",hint:"State one clear, measurable mission goal.",type:"textarea",full:true},
      {id:"users",label:"Users and beneficiaries",hint:"Who will use the result or benefit from it?",type:"text"},
      {id:"success",label:"Success criteria",hint:"How will the team know the mission succeeded?",type:"textarea",full:true},
      {id:"operations",label:"Mission workflow",hint:"Explain the system from start to finish.",type:"textarea",full:true},
      {id:"risks",label:"Risks and mitigations",hint:"List key technical, safety, environmental, or ethical risks.",type:"textarea",full:true},
      {id:"limits",label:"Constraints and limitations",hint:"Be honest about assumptions, cost, access, and technical limits.",type:"textarea",full:true},
      {id:"impact",label:"Expected impact",hint:"What changes if the mission works?",type:"textarea",full:true}
    ],
    fields: {
      cubesat: [
        {id:"payload",label:"Payload and data product",hint:"What will the satellite measure, observe, or communicate?",type:"textarea",full:true},
        {id:"orbit",label:"Orbit concept",hint:"Choose and justify altitude, inclination, coverage, or revisit conceptually.",type:"textarea",full:true},
        {id:"subsystems",label:"Subsystem architecture",hint:"Power, communications, onboard computer, structure, thermal, attitude control.",type:"textarea",full:true},
        {id:"ground",label:"Ground segment and data flow",hint:"How does data reach users?",type:"textarea",full:true}
      ],
      drones: [
        {id:"vehicle",label:"Drone architecture",hint:"Multirotor, fixed-wing, hybrid, or another concept — and why?",type:"textarea",full:true},
        {id:"payload",label:"Payload and data",hint:"Camera, sensor, delivery payload, or another mission tool.",type:"textarea",full:true},
        {id:"route",label:"Route and flight phases",hint:"Takeoff, transit, task, contingency, return, and landing.",type:"textarea",full:true},
        {id:"safety",label:"Safety and operational boundaries",hint:"People, property, weather, privacy, communications, and emergency actions.",type:"textarea",full:true}
      ],
      robotics: [
        {id:"sensors",label:"Sensors and inputs",hint:"What does the robot need to detect or measure?",type:"textarea",full:true},
        {id:"actuators",label:"Actuators and outputs",hint:"How will the robot move or act?",type:"textarea",full:true},
        {id:"controller",label:"Controller and logic",hint:"Describe states, rules, pseudocode, or a flowchart.",type:"textarea",full:true},
        {id:"testing",label:"Prototype and testing plan",hint:"What will be built or simulated, and how will it be tested?",type:"textarea",full:true}
      ]
    },
    ideas: {
      cubesat:["Monitor shoreline change along Egypt’s coasts.","Map vegetation stress and desertification risk.","Design an emergency communication CubeSat concept.","Track urban heat patterns over growing cities.","Support water-quality research along the Nile."],
      drones:["Inspect a solar farm for damaged panels.","Map flooded roads for emergency responders.","Survey crop health and irrigation needs.","Create a safe medical-supply delivery concept.","Document an archaeological site without disturbing it."],
      robotics:["Build a smart recycling sorter for a school.","Design a greenhouse monitoring and control system.","Create a search-and-signal rover for a mock disaster zone.","Develop a classroom energy-monitoring system.","Design an accessible carrying assistant robot."]
    },
    reportLabels:{problem:"Problem",objective:"Mission objective",users:"Users and beneficiaries",success:"Success criteria",operations:"Mission workflow",risks:"Risks and mitigations",limits:"Constraints and limitations",impact:"Expected impact",payload:"Payload / mission tool",orbit:"Orbit concept",subsystems:"System architecture",ground:"Ground segment and data flow",vehicle:"Drone architecture",route:"Route and flight phases",safety:"Safety and operational boundaries",sensors:"Sensors and inputs",actuators:"Actuators and outputs",controller:"Controller and logic",testing:"Prototype and testing plan"}
  },
  ar: {
    ui: {
      openSource: "مفتوح المصدر • عربي + إنجليزي",
      heroTitle: "صمّم مهمة هندسية حقيقية.",
      heroCopy: "اختر المسار، حدّد المشكلة، اتخذ قرارات هندسية، ثم صدّر تقريرًا متكاملًا لمشروع الطالب.",
      chooseTrack: "اختر المسار", surprise: "اقترح لي فكرة", buildMission: "ابنِ المهمة", autosaved: "تم الحفظ محليًا", generate: "إنشاء تقرير المهمة", clear: "مسح", report: "تقرير المهمة", download: "تحميل بصيغة Markdown", print: "طباعة", footer: "معرفة مفتوحة. هندسة حقيقية. فرص للجميع."
    },
    tracks: {
      cubesat: { icon:"🛰️", title:"تصميم مهمة قمر صناعي صغير", desc:"صمّم الهدف والحمولة والمدار والأنظمة الفرعية وخطة التشغيل." },
      drones: { icon:"🚁", title:"هندسة مهام الطائرات بدون طيار", desc:"خطّط لمهمة مفيدة تشمل الحمولة والمسار والسلامة وسير التشغيل." },
      robotics: { icon:"🤖", title:"الروبوتات والأنظمة الذكية", desc:"صمّم روبوتًا باستخدام المستشعرات والمشغلات ومنطق التحكم والاختبار." }
    },
    common: [
      {id:"projectTitle",label:"اسم المشروع",hint:"اختر اسمًا واضحًا ومميزًا للمهمة.",type:"text"},
      {id:"team",label:"اسم الطالب أو الفريق",hint:"اسم الطالب أو اسم الفريق.",type:"text"},
      {id:"problem",label:"المشكلة الواقعية",hint:"من المتأثر بها؟ وأين؟ ولماذا هي مهمة؟",type:"textarea",full:true},
      {id:"objective",label:"هدف المهمة",hint:"اكتب هدفًا واحدًا واضحًا وقابلًا للقياس.",type:"textarea",full:true},
      {id:"users",label:"المستخدمون والمستفيدون",hint:"من سيستخدم النتيجة أو يستفيد منها؟",type:"text"},
      {id:"success",label:"معايير النجاح",hint:"كيف سيعرف الفريق أن المهمة نجحت؟",type:"textarea",full:true},
      {id:"operations",label:"سير عمل المهمة",hint:"اشرح النظام من البداية حتى النهاية.",type:"textarea",full:true},
      {id:"risks",label:"المخاطر وطرق الحد منها",hint:"اذكر المخاطر التقنية أو المتعلقة بالسلامة أو البيئة أو الأخلاقيات.",type:"textarea",full:true},
      {id:"limits",label:"القيود والحدود",hint:"وضّح الافتراضات والتكلفة والإمكانات والحدود التقنية بصدق.",type:"textarea",full:true},
      {id:"impact",label:"الأثر المتوقع",hint:"ما الذي سيتغير إذا نجحت المهمة؟",type:"textarea",full:true}
    ],
    fields: {
      cubesat: [
        {id:"payload",label:"الحمولة وناتج البيانات",hint:"ماذا سيقيس أو يراقب أو يرسل القمر الصناعي؟",type:"textarea",full:true},
        {id:"orbit",label:"تصور المدار",hint:"اختر وفسّر الارتفاع والميل والتغطية أو زمن إعادة المرور بشكل مبسط.",type:"textarea",full:true},
        {id:"subsystems",label:"هيكل الأنظمة الفرعية",hint:"الطاقة والاتصالات والحاسوب والهيكل والحرارة والتحكم في الاتجاه.",type:"textarea",full:true},
        {id:"ground",label:"المحطة الأرضية وتدفق البيانات",hint:"كيف تصل البيانات إلى المستخدمين؟",type:"textarea",full:true}
      ],
      drones: [
        {id:"vehicle",label:"تصميم الطائرة",hint:"متعددة المراوح أم ثابتة الجناح أم هجينة؟ ولماذا؟",type:"textarea",full:true},
        {id:"payload",label:"الحمولة والبيانات",hint:"كاميرا أو مستشعر أو حمولة توصيل أو أداة أخرى.",type:"textarea",full:true},
        {id:"route",label:"المسار ومراحل الطيران",hint:"الإقلاع والانتقال وتنفيذ المهمة والطوارئ والعودة والهبوط.",type:"textarea",full:true},
        {id:"safety",label:"السلامة وحدود التشغيل",hint:"الأشخاص والممتلكات والطقس والخصوصية والاتصالات والطوارئ.",type:"textarea",full:true}
      ],
      robotics: [
        {id:"sensors",label:"المستشعرات والمدخلات",hint:"ما الذي يحتاج الروبوت إلى اكتشافه أو قياسه؟",type:"textarea",full:true},
        {id:"actuators",label:"المشغلات والمخرجات",hint:"كيف سيتحرك الروبوت أو ينفذ الفعل؟",type:"textarea",full:true},
        {id:"controller",label:"وحدة التحكم والمنطق",hint:"اشرح الحالات والقواعد أو الكود الوصفي أو مخطط التدفق.",type:"textarea",full:true},
        {id:"testing",label:"خطة النموذج والاختبار",hint:"ما الذي سيتم بناؤه أو محاكاته؟ وكيف سيُختبر؟",type:"textarea",full:true}
      ]
    },
    ideas: {
      cubesat:["مراقبة تغير السواحل المصرية.","رصد تدهور الغطاء النباتي ومخاطر التصحر.","تصميم قمر صناعي صغير للاتصالات وقت الطوارئ.","تتبع ظاهرة الجزر الحرارية في المدن.","دعم أبحاث جودة المياه على امتداد نهر النيل."],
      drones:["فحص محطة طاقة شمسية لاكتشاف الألواح التالفة.","رسم خريطة للطرق المتضررة من السيول.","تقييم صحة المحاصيل واحتياجات الري.","تصميم مهمة آمنة لتوصيل مستلزمات طبية.","توثيق موقع أثري دون الإضرار به."],
      robotics:["نظام ذكي لفرز المخلفات في المدرسة.","نظام لمراقبة الصوبة الزراعية والتحكم فيها.","عربة بحث وإشارة لمنطقة كوارث تجريبية.","نظام لمراقبة استهلاك الطاقة في الفصل.","روبوت مساعد لحمل الأشياء الخفيفة." ]
    },
    reportLabels:{problem:"المشكلة",objective:"هدف المهمة",users:"المستخدمون والمستفيدون",success:"معايير النجاح",operations:"سير عمل المهمة",risks:"المخاطر وطرق الحد منها",limits:"القيود والحدود",impact:"الأثر المتوقع",payload:"الحمولة أو أداة المهمة",orbit:"تصور المدار",subsystems:"هيكل النظام",ground:"المحطة الأرضية وتدفق البيانات",vehicle:"تصميم الطائرة",route:"المسار ومراحل الطيران",safety:"السلامة وحدود التشغيل",sensors:"المستشعرات والمدخلات",actuators:"المشغلات والمخرجات",controller:"وحدة التحكم والمنطق",testing:"خطة النموذج والاختبار"}
  }
};
