# Feature Plan

## Release 1.0 — Public MVP

- Bilingual Arabic–English interface
- Track selection
- Guided mission forms
- Idea generator
- Mission report preview
- Markdown export
- Print mode
- Autosave
- 15 project briefs
- 3 curricula and rubrics

## Release 1.1 — Engineering Calculators

- CubeSat power-budget calculator
- Simple orbit comparison tool
- Drone endurance estimator
- Robotics battery and current estimator
- Downloadable engineering worksheets

## Release 1.2 — Classroom Mode

- Teacher checklist
- Team codes
- Submission status board
- Rubric scoring interface
- CSV export

## Release 2.0 — Community Platform

- Accounts and team collaboration
- Public project gallery
- Educator resource exchange
- Versioned curriculum packs
- Moderation and safeguarding workflow
- Contributor recognition page

## Prioritization rule

A feature should be built only when it improves at least one of the following:

- Student learning quality
- Educator delivery time
- Accessibility
- Project documentation
- Community contribution
