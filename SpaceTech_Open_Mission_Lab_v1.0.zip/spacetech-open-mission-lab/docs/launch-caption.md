# Launch Caption

🚀 **Introducing SpaceTech Open Mission Lab**

SpaceTech Academy is proud to launch an open-source Arabic–English platform that helps school students turn real-world problems into complete engineering missions.

Students can explore three tracks:

🛰️ CubeSat and satellite mission design  
🚁 Drone and UAV mission engineering  
🤖 Robotics and smart systems

The first release includes a working mission builder, three complete course structures, project briefs, assessment rubrics, and free resources for students, teachers, schools, and STEM clubs.

The platform and its educational materials are publicly available for people to use, adapt, translate, and improve.

**Open knowledge. Real engineering. Opportunities for everyone.**
