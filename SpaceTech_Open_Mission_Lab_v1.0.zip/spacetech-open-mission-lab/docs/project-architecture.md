# Project Architecture

## Product goal

Create a free, bilingual, low-bandwidth platform that guides school students through a complete engineering mission-design process and gives educators ready-to-run teaching materials.

## Users

1. **Student:** builds and exports a mission proposal.
2. **Teacher:** runs an 8-session course and assesses projects.
3. **School or club:** uses the toolkit for a challenge or demo day.
4. **Contributor:** adds translations, project briefs, or tools.

## MVP architecture

The first release is intentionally static:

- HTML for structure
- CSS for responsive design and printing
- Vanilla JavaScript for interaction
- Browser `localStorage` for autosave
- Markdown export for portable reports

No server, database, account, or paid service is required.

## Content architecture

Each track contains:

- Track definition and learning outcomes
- Eight-session curriculum
- Student mission-builder fields
- Five project briefs
- One 100-point rubric

## Future architecture

A later release may add:

- Optional backend authentication
- Team workspaces
- Teacher dashboards
- Project gallery and moderation
- PDF export service
- Simulation modules
- Analytics with privacy-preserving defaults
