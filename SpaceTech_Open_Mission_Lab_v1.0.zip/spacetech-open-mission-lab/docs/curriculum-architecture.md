# Curriculum Architecture

## Shared learning model

All tracks follow the same eight-stage project journey:

1. Explore the system and a real-world problem.
2. Define users, needs, and mission success.
3. Select components or subsystems.
4. Design the mission workflow.
5. Calculate or justify feasibility.
6. Identify risks, safety, and ethics.
7. Build the final report or prototype evidence.
8. Present, defend, and improve the project.

## Shared session structure

Each 90-minute session uses:

- 10 minutes: mission hook
- 20 minutes: technical concept
- 20 minutes: guided example
- 30 minutes: team design sprint
- 10 minutes: checkpoint and reflection

## Assessment model

- 20% participation and engineering notebook
- 20% milestone submissions
- 20% technical understanding
- 30% final project quality
- 10% presentation and reflection

## Final student outputs

Every student or team should produce:

- Problem statement
- Mission objective
- System diagram
- Component or subsystem choices
- Operational workflow
- Feasibility justification
- Risk and safety analysis
- Impact statement
- Final pitch
