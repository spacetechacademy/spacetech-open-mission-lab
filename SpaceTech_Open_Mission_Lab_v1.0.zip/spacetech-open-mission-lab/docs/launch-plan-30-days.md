# 30-Day Open-Source Launch Roadmap

## Week 1 — Build and verify

- Finalize repository name and public description.
- Review technical terminology in Arabic and English.
- Test the web app on mobile and desktop.
- Confirm MIT and CC BY 4.0 licensing.
- Recruit three reviewers: one educator, one engineering student, one school learner.

**Public proof:** teaser image showing the three tracks.

## Week 2 — Pilot

- Run a 45-minute online pilot with 5–10 students.
- Ask each student to complete one mission outline.
- Record usability problems and confusing terms.
- Improve the mission builder and project briefs.

**Public proof:** anonymized pilot statistics and student feedback.

## Week 3 — Release candidate

- Publish the repository on GitHub.
- Enable GitHub Pages for the web app.
- Create version tag `v1.0.0`.
- Prepare screenshots, a one-minute demo, and launch copy.
- Archive the release on Zenodo after connecting the GitHub repository.

**Public proof:** live platform, public code, and versioned release.

## Week 4 — Public launch

- Announce SpaceTech Open Mission Lab.
- Invite schools and educators to pilot it for free.
- Open a contributor form for translations and project briefs.
- Publish one featured student mission per week.
- Contact STEM communities, schools, and university clubs.

**Launch metrics:**

- 100 unique platform visits
- 25 mission reports created
- 5 educators contacted
- 3 external contributors or reviewers
- 1 school or club pilot confirmed

## Launch statement

> SpaceTech Academy has launched an open-source Arabic–English mission-design platform that gives students and educators free tools, curricula, project briefs, and assessment resources across satellite systems, drones, and robotics.
