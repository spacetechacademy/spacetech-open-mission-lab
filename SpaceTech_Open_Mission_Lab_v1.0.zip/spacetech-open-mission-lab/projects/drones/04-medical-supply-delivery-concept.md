# Medical Supply Delivery Concept

**Track:** Drones

## Challenge

Design a limited-range delivery mission for urgent medical supplies to a hard-to-reach location.

## Intended users

Clinics and emergency services.

## Required outputs

Address payload mass, route, handoff, weather, safety, and ethics.

Every submission should also include:

- Mission objective and success criteria
- System or mission diagram
- Key component choices
- Operational workflow
- Risk, safety, and ethics notes
- Feasibility limits
- Final 3–5 minute pitch

## Constraints

- Use evidence and realistic assumptions.
- Do not claim the concept is deployment-ready.
- Protect privacy and prioritize human safety.
- Clearly label simulated or estimated results.

## Stretch goal

Create one quantitative estimate, simple simulation, prototype test, or comparison that supports the design.
