# Precision Agriculture Survey

**Track:** Drones

## Challenge

Design a drone mission for crop health assessment and irrigation planning.

## Intended users

Farmers and agricultural engineers.

## Required outputs

Specify route, sensors, altitude rationale, safety plan, and outputs.

Every submission should also include:

- Mission objective and success criteria
- System or mission diagram
- Key component choices
- Operational workflow
- Risk, safety, and ethics notes
- Feasibility limits
- Final 3–5 minute pitch

## Constraints

- Use evidence and realistic assumptions.
- Do not claim the concept is deployment-ready.
- Protect privacy and prioritize human safety.
- Clearly label simulated or estimated results.

## Stretch goal

Create one quantitative estimate, simple simulation, prototype test, or comparison that supports the design.
