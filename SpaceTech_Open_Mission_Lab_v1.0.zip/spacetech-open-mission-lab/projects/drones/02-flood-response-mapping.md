# Flood Response Mapping

**Track:** Drones

## Challenge

Rapidly map roads, buildings, and isolated areas after flooding.

## Intended users

Emergency responders and local authorities.

## Required outputs

Plan deployment, route, data delivery, contingencies, and human safety.

Every submission should also include:

- Mission objective and success criteria
- System or mission diagram
- Key component choices
- Operational workflow
- Risk, safety, and ethics notes
- Feasibility limits
- Final 3–5 minute pitch

## Constraints

- Use evidence and realistic assumptions.
- Do not claim the concept is deployment-ready.
- Protect privacy and prioritize human safety.
- Clearly label simulated or estimated results.

## Stretch goal

Create one quantitative estimate, simple simulation, prototype test, or comparison that supports the design.
