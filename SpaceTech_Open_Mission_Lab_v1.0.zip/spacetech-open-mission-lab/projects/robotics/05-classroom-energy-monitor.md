# Classroom Energy Monitor

**Track:** Robotics

## Challenge

Measure room conditions and recommend actions that reduce wasted energy.

## Intended users

Schools and facility teams.

## Required outputs

Select sensors, define logic, dashboard outputs, and evaluation plan.

Every submission should also include:

- Mission objective and success criteria
- System or mission diagram
- Key component choices
- Operational workflow
- Risk, safety, and ethics notes
- Feasibility limits
- Final 3–5 minute pitch

## Constraints

- Use evidence and realistic assumptions.
- Do not claim the concept is deployment-ready.
- Protect privacy and prioritize human safety.
- Clearly label simulated or estimated results.

## Stretch goal

Create one quantitative estimate, simple simulation, prototype test, or comparison that supports the design.
