# Search-and-Signal Rover

**Track:** Robotics

## Challenge

Create a small rover concept that searches a mock disaster area and signals detected obstacles or targets.

## Intended users

Training teams and rescue education programs.

## Required outputs

Define mobility, sensing, communication, test arena, and limitations.

Every submission should also include:

- Mission objective and success criteria
- System or mission diagram
- Key component choices
- Operational workflow
- Risk, safety, and ethics notes
- Feasibility limits
- Final 3–5 minute pitch

## Constraints

- Use evidence and realistic assumptions.
- Do not claim the concept is deployment-ready.
- Protect privacy and prioritize human safety.
- Clearly label simulated or estimated results.

## Stretch goal

Create one quantitative estimate, simple simulation, prototype test, or comparison that supports the design.
