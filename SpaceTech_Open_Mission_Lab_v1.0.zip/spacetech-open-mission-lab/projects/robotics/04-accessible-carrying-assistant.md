# Accessible Carrying Assistant

**Track:** Robotics

## Challenge

Design a robot or smart cart that helps carry lightweight items safely.

## Intended users

People with mobility limitations and caregivers.

## Required outputs

Focus on user interaction, obstacle detection, stopping logic, and ethics.

Every submission should also include:

- Mission objective and success criteria
- System or mission diagram
- Key component choices
- Operational workflow
- Risk, safety, and ethics notes
- Feasibility limits
- Final 3–5 minute pitch

## Constraints

- Use evidence and realistic assumptions.
- Do not claim the concept is deployment-ready.
- Protect privacy and prioritize human safety.
- Clearly label simulated or estimated results.

## Stretch goal

Create one quantitative estimate, simple simulation, prototype test, or comparison that supports the design.
