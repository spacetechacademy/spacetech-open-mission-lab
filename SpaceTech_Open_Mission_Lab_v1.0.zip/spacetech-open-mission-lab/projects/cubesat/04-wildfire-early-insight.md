# Wildfire Early Insight

**Track:** Cubesat

## Challenge

Support early identification and post-event assessment of wildfire or heat anomalies.

## Intended users

Civil protection and environmental teams.

## Required outputs

Explain sensing concept, alert workflow, false positives, and data latency.

Every submission should also include:

- Mission objective and success criteria
- System or mission diagram
- Key component choices
- Operational workflow
- Risk, safety, and ethics notes
- Feasibility limits
- Final 3–5 minute pitch

## Constraints

- Use evidence and realistic assumptions.
- Do not claim the concept is deployment-ready.
- Protect privacy and prioritize human safety.
- Clearly label simulated or estimated results.

## Stretch goal

Create one quantitative estimate, simple simulation, prototype test, or comparison that supports the design.
