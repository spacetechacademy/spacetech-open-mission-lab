# Emergency Communication CubeSat

**Track:** Cubesat

## Challenge

Provide a conceptual emergency messaging service when terrestrial communications are disrupted.

## Intended users

Emergency responders and affected communities.

## Required outputs

Design communications flow, users, ground segment, capacity assumptions, and constraints.

Every submission should also include:

- Mission objective and success criteria
- System or mission diagram
- Key component choices
- Operational workflow
- Risk, safety, and ethics notes
- Feasibility limits
- Final 3–5 minute pitch

## Constraints

- Use evidence and realistic assumptions.
- Do not claim the concept is deployment-ready.
- Protect privacy and prioritize human safety.
- Clearly label simulated or estimated results.

## Stretch goal

Create one quantitative estimate, simple simulation, prototype test, or comparison that supports the design.
