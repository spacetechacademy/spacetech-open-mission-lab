# Nile Water Watch

**Track:** Cubesat

## Challenge

Design a CubeSat mission that helps monitor water quality indicators and pollution risks along the Nile.

## Intended users

Environmental agencies, researchers, and communities.

## Required outputs

Define payload data, target regions, orbit rationale, data products, and limitations.

Every submission should also include:

- Mission objective and success criteria
- System or mission diagram
- Key component choices
- Operational workflow
- Risk, safety, and ethics notes
- Feasibility limits
- Final 3–5 minute pitch

## Constraints

- Use evidence and realistic assumptions.
- Do not claim the concept is deployment-ready.
- Protect privacy and prioritize human safety.
- Clearly label simulated or estimated results.

## Stretch goal

Create one quantitative estimate, simple simulation, prototype test, or comparison that supports the design.
