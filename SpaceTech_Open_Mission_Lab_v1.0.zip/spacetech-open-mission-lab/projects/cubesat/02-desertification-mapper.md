# Desertification Mapper

**Track:** Cubesat

## Challenge

Map changes in vegetation and land condition near vulnerable agricultural areas.

## Intended users

Farmers, environmental planners, and researchers.

## Required outputs

Explain imaging needs, revisit expectations, seasonal effects, and impact.

Every submission should also include:

- Mission objective and success criteria
- System or mission diagram
- Key component choices
- Operational workflow
- Risk, safety, and ethics notes
- Feasibility limits
- Final 3–5 minute pitch

## Constraints

- Use evidence and realistic assumptions.
- Do not claim the concept is deployment-ready.
- Protect privacy and prioritize human safety.
- Clearly label simulated or estimated results.

## Stretch goal

Create one quantitative estimate, simple simulation, prototype test, or comparison that supports the design.
