# Coastal Change Observer

**Track:** Cubesat

## Challenge

Track shoreline change, erosion, and development along the Mediterranean and Red Sea coasts.

## Intended users

Coastal authorities and researchers.

## Required outputs

Design the payload, image schedule, comparison method, and risk controls.

Every submission should also include:

- Mission objective and success criteria
- System or mission diagram
- Key component choices
- Operational workflow
- Risk, safety, and ethics notes
- Feasibility limits
- Final 3–5 minute pitch

## Constraints

- Use evidence and realistic assumptions.
- Do not claim the concept is deployment-ready.
- Protect privacy and prioritize human safety.
- Clearly label simulated or estimated results.

## Stretch goal

Create one quantitative estimate, simple simulation, prototype test, or comparison that supports the design.
