# Robotics & Smart Systems — Final Project Rubric

| Criterion | Points | Evidence expected |
|---|---:|---|
| Problem relevance and user need | 15 | The problem is meaningful and the user need is understood. |
| System architecture | 20 | Sensors, controller, actuators, energy, and communication connect coherently. |
| Control logic and coding | 20 | Logic is clear, testable, and appropriate for the system. |
| Prototype or simulation evidence | 20 | Evidence demonstrates that key functions were tested. |
| Testing, safety, and feasibility | 10 | Tests, limitations, safety, and improvement steps are documented. |
| Communication and teamwork | 15 | Clear report, visuals, presentation, and balanced team contribution. |
| **Total** | **100** | |

## Performance Bands

- **90–100:** Exceptional and competition-ready
- **75–89:** Strong with minor improvements needed
- **60–74:** Developing; major design areas need refinement
- **Below 60:** Incomplete evidence or weak engineering justification