# Robotics & Smart Systems — 8-Session Curriculum

**Recommended age:** 12–18

**Final outcome:** A robotics or smart-system concept, prototype, or simulation with sensors, actuators, controller logic, system architecture, testing evidence, and final pitch.

## Session Map

### Session 1: Robotics for Real Problems

**Learning objective:** Identify a user need and understand sensing, thinking, and acting.

**Student output:** Problem statement and robot function.

**Suggested flow:** hook → concept → worked example → team sprint → checkpoint.

### Session 2: System Requirements

**Learning objective:** Define tasks, environment, constraints, and success metrics.

**Student output:** Requirements and test criteria.

**Suggested flow:** hook → concept → worked example → team sprint → checkpoint.

### Session 3: Sensors & Inputs

**Learning objective:** Select sensors and plan how data is measured and interpreted.

**Student output:** Sensor table and input diagram.

**Suggested flow:** hook → concept → worked example → team sprint → checkpoint.

### Session 4: Actuators, Motors & Mechanics

**Learning objective:** Choose movement or output devices and define physical behavior.

**Student output:** Actuator and mechanism concept.

**Suggested flow:** hook → concept → worked example → team sprint → checkpoint.

### Session 5: Controller & Logic

**Learning objective:** Design Arduino/ESP32-style control logic using states, conditions, and flowcharts.

**Student output:** Control-flow diagram or pseudocode.

**Suggested flow:** hook → concept → worked example → team sprint → checkpoint.

### Session 6: Power, Communication & Integration

**Learning objective:** Plan energy, wiring, communication, and subsystem integration.

**Student output:** System block diagram and bill of materials.

**Suggested flow:** hook → concept → worked example → team sprint → checkpoint.

### Session 7: Prototype, Simulation & Testing

**Learning objective:** Build or simulate a minimum viable system and collect test evidence.

**Student output:** Prototype evidence and test results.

**Suggested flow:** hook → concept → worked example → team sprint → checkpoint.

### Session 8: Demo Day & Engineering Review

**Learning objective:** Demonstrate the system, answer questions, and document improvements.

**Student output:** Final report, demonstration, and pitch.

**Suggested flow:** hook → concept → worked example → team sprint → checkpoint.

## Delivery Notes

- Recommended duration: 90 minutes per session.
- Students may work individually or in teams of 2–4.
- Keep an engineering notebook throughout the course.
- Require evidence for major design decisions.
- End each session with one visible deliverable.
