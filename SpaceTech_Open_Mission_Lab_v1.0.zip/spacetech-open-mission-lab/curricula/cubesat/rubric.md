# CubeSat & Satellite Mission Design — Final Project Rubric

| Criterion | Points | Evidence expected |
|---|---:|---|
| Mission need and impact | 15 | Clear problem, beneficiaries, and measurable value. |
| Technical architecture | 25 | Coherent system diagram and justified subsystem choices. |
| Payload and data logic | 15 | Payload fits the objective and produces useful information. |
| Orbit and operations reasoning | 15 | Orbit and operations are logically connected to mission success. |
| Feasibility, risk, and ethics | 15 | Constraints, risks, safety, ethics, and mitigations are considered. |
| Communication and teamwork | 15 | Clear report, visuals, presentation, and balanced team contribution. |
| **Total** | **100** | |

## Performance Bands

- **90–100:** Exceptional and competition-ready
- **75–89:** Strong with minor improvements needed
- **60–74:** Developing; major design areas need refinement
- **Below 60:** Incomplete evidence or weak engineering justification