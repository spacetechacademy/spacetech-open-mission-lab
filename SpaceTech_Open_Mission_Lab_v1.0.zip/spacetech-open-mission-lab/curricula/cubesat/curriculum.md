# CubeSat & Satellite Mission Design — 8-Session Curriculum

**Recommended age:** 12–18

**Final outcome:** A complete CubeSat mission proposal with objective, payload, orbit concept, subsystem architecture, operations plan, risk analysis, and final pitch.

## Session Map

### Session 1: Mission Discovery

**Learning objective:** Understand CubeSats, identify a real-world problem, and define mission users.

**Student output:** Problem map and first mission statement.

**Suggested flow:** hook → concept → worked example → team sprint → checkpoint.

### Session 2: Mission Requirements

**Learning objective:** Turn the problem into measurable mission objectives and success criteria.

**Student output:** Mission objective, stakeholders, and success metrics.

**Suggested flow:** hook → concept → worked example → team sprint → checkpoint.

### Session 3: Payload Design

**Learning objective:** Select a payload and explain what data or service it provides.

**Student output:** Payload concept sheet and data products.

**Suggested flow:** hook → concept → worked example → team sprint → checkpoint.

### Session 4: Satellite Subsystems

**Learning objective:** Connect power, communications, onboard computer, structure, thermal, and attitude control.

**Student output:** Labeled subsystem block diagram.

**Suggested flow:** hook → concept → worked example → team sprint → checkpoint.

### Session 5: Orbit & Coverage

**Learning objective:** Compare simple orbit choices and justify altitude, inclination, revisit, and ground coverage conceptually.

**Student output:** Orbit rationale and coverage sketch.

**Suggested flow:** hook → concept → worked example → team sprint → checkpoint.

### Session 6: Operations, Ground Station & Data

**Learning objective:** Design the mission timeline from launch to data delivery.

**Student output:** Concept of operations and communication flow.

**Suggested flow:** hook → concept → worked example → team sprint → checkpoint.

### Session 7: Risk, Ethics & Feasibility

**Learning objective:** Evaluate technical risks, space debris, data ethics, cost, and constraints.

**Student output:** Risk register and feasibility argument.

**Suggested flow:** hook → concept → worked example → team sprint → checkpoint.

### Session 8: Mission Review & Pitch

**Learning objective:** Defend the mission to a review panel and revise it using feedback.

**Student output:** Final report, poster, and 5-minute pitch.

**Suggested flow:** hook → concept → worked example → team sprint → checkpoint.

## Delivery Notes

- Recommended duration: 90 minutes per session.
- Students may work individually or in teams of 2–4.
- Keep an engineering notebook throughout the course.
- Require evidence for major design decisions.
- End each session with one visible deliverable.
