# Drone & UAV Mission Engineering — Final Project Rubric

| Criterion | Points | Evidence expected |
|---|---:|---|
| Mission value and user need | 15 | Clear real-world purpose and defined user. |
| Vehicle and payload design | 20 | Airframe and payload choices fit the mission. |
| Route and operations | 20 | Complete mission workflow with contingencies. |
| Safety and risk control | 20 | Hazards, privacy, people, property, and mitigations are addressed. |
| Feasibility and innovation | 10 | Design is realistic while showing thoughtful originality. |
| Communication and teamwork | 15 | Clear report, visuals, presentation, and balanced team contribution. |
| **Total** | **100** | |

## Performance Bands

- **90–100:** Exceptional and competition-ready
- **75–89:** Strong with minor improvements needed
- **60–74:** Developing; major design areas need refinement
- **Below 60:** Incomplete evidence or weak engineering justification