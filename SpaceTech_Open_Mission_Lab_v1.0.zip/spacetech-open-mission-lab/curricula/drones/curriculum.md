# Drone & UAV Mission Engineering — 8-Session Curriculum

**Recommended age:** 13–18

**Final outcome:** A complete UAV mission design with use case, aircraft concept, payload, route, safety plan, operations workflow, and feasibility justification.

## Session Map

### Session 1: UAV Systems & Applications

**Learning objective:** Explore multirotor and fixed-wing systems and identify a useful mission.

**Student output:** Problem statement and mission user.

**Suggested flow:** hook → concept → worked example → team sprint → checkpoint.

### Session 2: Mission Requirements

**Learning objective:** Define payload, range, time, environment, and success criteria.

**Student output:** Requirements table.

**Suggested flow:** hook → concept → worked example → team sprint → checkpoint.

### Session 3: Airframe, Propulsion & Energy

**Learning objective:** Select a suitable drone architecture and justify basic propulsion and battery choices.

**Student output:** Vehicle concept and component rationale.

**Suggested flow:** hook → concept → worked example → team sprint → checkpoint.

### Session 4: Sensors, Payload & Data

**Learning objective:** Choose sensors or payloads and define the data collection process.

**Student output:** Payload diagram and data plan.

**Suggested flow:** hook → concept → worked example → team sprint → checkpoint.

### Session 5: Route & Mission Workflow

**Learning objective:** Design takeoff, transit, task, contingency, return, and landing phases.

**Student output:** Route sketch and concept of operations.

**Suggested flow:** hook → concept → worked example → team sprint → checkpoint.

### Session 6: Control, Autonomy & Communications

**Learning objective:** Explain manual, assisted, and autonomous control, telemetry, and communications.

**Student output:** Control and communication flowchart.

**Suggested flow:** hook → concept → worked example → team sprint → checkpoint.

### Session 7: Safety, Risk & Regulation Awareness

**Learning objective:** Identify hazards, mitigations, privacy, human safety, and operational boundaries.

**Student output:** Risk assessment and safety checklist.

**Suggested flow:** hook → concept → worked example → team sprint → checkpoint.

### Session 8: Design Review & Pitch

**Learning objective:** Present the complete mission and improve it after panel questions.

**Student output:** Final report, mission board, and pitch.

**Suggested flow:** hook → concept → worked example → team sprint → checkpoint.

## Delivery Notes

- Recommended duration: 90 minutes per session.
- Students may work individually or in teams of 2–4.
- Keep an engineering notebook throughout the course.
- Require evidence for major design decisions.
- End each session with one visible deliverable.
